package com.project.service;

import static org.junit.Assert.assertNotNull;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.project.domain.QnABoardVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class QnABoardServiceTest2 {
	
	@Setter(onMethod_ = {@Autowired})
	private QnABoardService service;
	
	@Test
	public void testRegister() {
		QnABoardVO qna_board = new QnABoardVO();
		qna_board.setQna_title("새로 작성해!!");
		qna_board.setQna_content("내용도 작성해해!");
		qna_board.setQna_writer("뉴비안녕");
		service.register(qna_board);
		log.info("생성된 게시물 번호 : "+qna_board.getQna_num());
	}//end test

}//end clas