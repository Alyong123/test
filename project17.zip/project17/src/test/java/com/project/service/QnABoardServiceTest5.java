package com.project.service;

import static org.junit.Assert.assertNotNull;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.project.domain.QnABoardVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class QnABoardServiceTest5 {
	
	@Setter(onMethod_ = {@Autowired})
	private QnABoardService qna_service;
	
	@Test
	public void testDelete() {
		//게시물의 번호 존재를 확인하고 테스트
		log.info("Remove RESULT..."+qna_service.remove(2L));
		
	}//end test

	@Test
	public void testUpdate() {
		QnABoardVO qna_board = qna_service.get(1L);
		if(qna_board == null) {
			return;
		}
		qna_board.setQna_title("제목 수정합니다.");
		log.info(""+qna_service.modify(qna_board));		
	}//end test
}//end class
