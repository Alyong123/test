package com.project.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.project.domain.QnABoardVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class QnABoardMapperTests {
	
	@Setter(onMethod_ = @Autowired)
	private QnABoardMapper mapper;
	
	// return 문장 하나로 쓰고 싶을 때, (for-each구문_자바1.5 이상 사용 가능)
	@Test
	public void testGetList() {
		mapper.getList().forEach(qna_board -> log.info(qna_board));		
	}//end void
	
	// 원래는 이런 형식
//	@Test
//	public void testGetList2() {
//		for(  BoardVO  board:mapper.getList() ) {
//			log.info(board);
//		}
//	}//end void

}//end class
