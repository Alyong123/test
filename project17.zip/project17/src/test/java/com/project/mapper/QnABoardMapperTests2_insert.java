package com.project.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.project.domain.QnABoardVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class QnABoardMapperTests2_insert {
	
	@Setter(onMethod_ = @Autowired)
	private QnABoardMapper mapper;
	
	@Test
	public void testInsert() {
		QnABoardVO qna_board = new QnABoardVO();
		qna_board.setQna_title("새로 작성하는 글");
		qna_board.setQna_content("새로 작성하는 글 내용");
		qna_board.setQna_writer("newbie");
		mapper.insert(qna_board);
		log.info(qna_board);
	}//end void
	
}//end class