package com.project.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.project.domain.USRMemberVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;


//작성자 : 신승배
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j

public class UserMemberMapperTest_upadate {
	@Setter(onMethod_ = @Autowired)
	private USRMemberMapper mapper;
	
	
	// 유저정보 수정했을때  db에 업데이트 되느지  테스트
	@Test
	public void testupate() {
		USRMemberVO  usr = new USRMemberVO();
		usr.setUsr_id("dd");
		usr.setUsr_passwd("dsafaf");
		usr.setUsr_name("wdqdqd");
		usr.setUsr_adtest(123);
		usr.setUsr_hp_num(01012341234);
		usr.setUsr_address("newie");
		mapper.update(usr);
		log.info("Update COUNT" + usr);	
	}//end void

}