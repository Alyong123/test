package com.project.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import com.project.domain.USRMemberVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;


//작성자 : 신승배
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j

public class UserMemberMapperTest_Insert {
	@Setter(onMethod_ = @Autowired)
	private USRMemberMapper mapper;
	
	
	// 유저정보 db에 잘들어가는지 테스트
	@Test
	public void testInsert() {
		USRMemberVO  usr = new USRMemberVO();
		usr.setUsr_id("user8");
		usr.setUsr_passwd("user1");
		usr.setUsr_name("user1");
		usr.setUsr_adtest(123);
		usr.setUsr_hp_num(01012341234);
		usr.setUsr_address("newie");
		mapper.usr_insert(usr);
		log.info(usr);
	}//end void

}