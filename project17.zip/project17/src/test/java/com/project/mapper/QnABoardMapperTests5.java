package com.project.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import com.project.domain.QnABoardVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class QnABoardMapperTests5 {
	
	@Setter(onMethod_ = @Autowired)
	private QnABoardMapper mapper;
	
	@Test
	public void testUpdate() {
		QnABoardVO qna_board = new QnABoardVO();
		//실행전 존재하는 번호인지 확인
		qna_board.setQna_num(5L);
		qna_board.setQna_title("수정된 제목");
		qna_board.setQna_content("수정된 내용");
		qna_board.setQna_writer("user00");
		
		int count = mapper.update(qna_board);
		log.info("Update COUNT" + count);		
	}
	
}//end class