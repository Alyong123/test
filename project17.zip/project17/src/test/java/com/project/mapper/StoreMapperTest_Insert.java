package com.project.mapper;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.project.domain.StoreVO;


import lombok.Setter;
import lombok.extern.log4j.Log4j;

// 작성자 : 신승배
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j

public class StoreMapperTest_Insert {
	@Setter(onMethod_ = @Autowired)
	private StoreMapper mapper;
	
	// 가게정보 db에  잘 들어가는지 테스트
	@Test 
	public void testInsert() {
		StoreVO store = new StoreVO();
		store.setLoca_num(3);
		store.setCate_num(3);
		store.setSto_name("테스트5");
		store.setCeo_name("테스트5");
		store.setSto_time("09:00");
		store.setSto_hp("테스트3");
		store.setSto_cont("테스트3");
		store.setSto_x(39.75849592948884);
		store.setSto_y(130.03297144986628);

		mapper.store_insert(store);
		log.info(store);
	}//end void

}