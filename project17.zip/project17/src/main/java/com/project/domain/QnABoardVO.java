package com.project.domain;

import java.util.Date;
import lombok.Data;

@Data
public class QnABoardVO {
	private Long qna_num;
	private String qna_title;
	private String qna_content;
	private String qna_writer;
	private Date qna_regdate;
	private Date qna_updateDate;
}//end class