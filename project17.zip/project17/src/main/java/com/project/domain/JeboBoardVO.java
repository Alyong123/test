package com.project.domain;

import java.util.Date;
import lombok.Data;

@Data
public class JeboBoardVO {
	private Long jebo_num;
	private String jebo_title;
	private String jebo_content;
	private String jebo_writer;
	private Date jebo_regdate;
	private Date jebo_updateDate;
}//end class
