package com.project.domain;

import lombok.Data;

@Data
public class HomeVO { //작성자 : 공영빈
	private Long sto_num;
	private String sto_name;
	private Double sto_x;
	private Double sto_y;
} // 업체 table의 업체번호, 업체명, x좌표, y좌표로 이루어진 VO. 마커를 찍을 때 필요한 정보만 가져옵니다.
