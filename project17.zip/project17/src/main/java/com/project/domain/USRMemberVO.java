package com.project.domain;

import lombok.Data;

@Data
public class USRMemberVO {	 //작성자 : 신승배
	private String  usr_id;
	private String usr_passwd;
	private String usr_name;
	private int usr_adtest;
	private int usr_hp_num;
	private String usr_address;
	

} // 회원가입된 유저 table이 가지고 있는 모든 정보로 이루어진 VO입니다.
