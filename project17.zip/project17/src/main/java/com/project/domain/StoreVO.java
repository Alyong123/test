package com.project.domain;

import lombok.Data;

@Data
public class StoreVO {	//작성자 : 공영빈
		private int sto_num;
		private int loca_num;
		private int cate_num;
		private String sto_name;
		private String ceo_name;
		private String sto_time;
		private String sto_hp;
		private String sto_cont;
		private double sto_x;
		private double sto_y;
		
}// 업체 table이 가지고 있는 모든 정보로 이루어진 VO입니다.
