package com.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.domain.StoreVO;
import com.project.mapper.StoreMapper;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class StoreServicelmpl implements StoreService {
	
	
	@Setter(onMethod_ = @Autowired)// 작성자 : 신승배     //의존성 주입
	private StoreMapper mapper; // StoreMapper의 메소드를 사용하기 위해  mapper라는 객체생성

	@Override
	public void store_register(StoreVO store) throws Exception { // 작성자 : 신승배
		log.info("store_register...."+store);
		mapper.store_insert(store);
	}// 업체정보를 db에 추가하는 메소드를 오버라이딩함

	@Override
	public StoreVO getList1(Long sto_num) { // 작성자 : 공영빈
		// TODO Auto-generated method stub
		return mapper.getList1(sto_num);
	} //업체 정보를 가져오는 메소드를 오버라이딩함.
}
