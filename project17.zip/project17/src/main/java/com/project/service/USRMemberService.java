package com.project.service;

import org.apache.ibatis.annotations.Param;

import com.project.domain.USRMemberVO;


//작성자 : 신승배
public interface USRMemberService {
	public void register(USRMemberVO usr) throws Exception;
	// 유저 정보를  추가하는 interface 메소드
	
	public USRMemberVO user_login(@Param("usr_id") String usr_id, @Param("usr_passwd") String usr_passwd);
	// 아이디와 비밀번호가 일치하는 유저를 찾아주는 interface 메소드
	
	public void  usr_modify(USRMemberVO usr);
	// 유저 정보 를 수정하는  interface 메소드
	
}
