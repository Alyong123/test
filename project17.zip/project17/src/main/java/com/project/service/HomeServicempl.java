package com.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.domain.HomeVO;
import com.project.mapper.HomeMapper;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class HomeServicempl implements HomeService { //작성자 : 공영빈
	
	@Setter(onMethod_ = @Autowired)
	private HomeMapper mapper;

	@Override
	public List<HomeVO> getList1() {
		log.info("List1");
		return mapper.getList1();
	}

	@Override
	public List<HomeVO> getList2() {
		log.info("List2");
		return mapper.getList2();
	}

	@Override
	public List<HomeVO> getList3() {
		log.info("List3");
		return mapper.getList3();
	}

	@Override
	public List<HomeVO> getList4() {
		log.info("List4");
		return mapper.getList4();
	}


}// 각 카테고리의 정보를 가져 올 메소드를 오버라이딩함.
