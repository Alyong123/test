package com.project.service;

import java.util.List;

import com.project.domain.HomeVO;

public interface HomeService { //작성자 : 공영빈
	
	public List<HomeVO> getList1();
	
	public List<HomeVO> getList2();
	
	public List<HomeVO> getList3();
	
	public List<HomeVO> getList4();
}// 각 카테고리의 정보를 가져 올 메소드
