package com.project.service;

import java.util.List;

import com.project.domain.QnABoardVO;
import com.project.domain.Criteria;

public interface QnABoardService {
	
	public int getTotal(Criteria cri);
	
	public void register(QnABoardVO qna_board);
	
	public QnABoardVO get(Long qna_num);
	
	public boolean modify(QnABoardVO qna_board);
	
	public boolean remove(Long qna_num);
	
	public List<QnABoardVO> getList();		
	
	public List<QnABoardVO> getList(Criteria cri);	
	
	public List<QnABoardVO> getIdList(String qna_writer);

}//end int