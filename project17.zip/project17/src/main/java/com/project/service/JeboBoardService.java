package com.project.service;

import java.util.List;

import com.project.domain.JeboBoardVO;
import com.project.domain.Criteria;

public interface JeboBoardService {
	
	public int getTotal(Criteria cri);
	
	public void register(JeboBoardVO jebo_board);
	
	public JeboBoardVO get(Long jebo_num);
	
	public boolean modify(JeboBoardVO jebo_board);
	
	public boolean remove(Long jebo_num);
	
	public List<JeboBoardVO> getList();		
	
	public List<JeboBoardVO> getList(Criteria cri);	
	
	public List<JeboBoardVO> getIdList(String jebo_writer);

}//end int
