package com.project.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.domain.Criteria;
import com.project.domain.QnABoardVO;
import com.project.mapper.QnABoardMapper;
import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class QnABoardServiceImpl implements QnABoardService{
	
	@Setter(onMethod_ = @Autowired)
	private QnABoardMapper mapper;

	@Override
	public void register(QnABoardVO qna_board) {
		log.info("register...."+qna_board);
		mapper.insertSelectKey(qna_board);
	}

	@Override
	public QnABoardVO get(Long qna_num) {
		log.info("get....."+qna_num);
		return mapper.read(qna_num);
	}

	@Override
	public boolean modify(QnABoardVO qna_board) {
		log.info("Modify....."+qna_board);
		return mapper.update(qna_board) == 1;
	}

	@Override
	public boolean remove(Long qna_num) {
		log.info("remove..." + qna_num);
		return mapper.delete(qna_num) ==1	;
	}

//	@Override
//	public int getTotal(Criteria cri) {
//		// TODO Auto-generated method stub
//		return 0;
//	}
	
//	@Override
//	public List<QnABoardVO> getList() {
//		log.info("get List.............");
//		return mapper.getList();
//	}
//
//	@Override
//	public List<QnABoardVO> getList(Criteria cri) {
//		log.info("get List with criteria..." + cri);
//		return mapper.getListWithPaging(cri);
//	}
	
	@Override
	public List<QnABoardVO> getList() {
		log.info("get List.............");
		return mapper.getList();
	}

	@Override
	public List<QnABoardVO> getList(Criteria cri) {
		log.info("get List with criteria..." + cri);
		return mapper.getListWithPaging(cri);
	}
	
	@Override
	public int getTotal(Criteria cri) {
		log.info("get total count");
		return mapper.getTotalCount(cri);
	}//end getList
	
	@Override
	public List<QnABoardVO> getIdList(String qna_writer) {	
		return mapper.readId(qna_writer);		
	}

}//end class