package com.project.service;

import java.util.List;

import com.project.domain.ReviewVO;

public interface ReviewService { // 작성자 : 공영빈

	public List<ReviewVO> getList1(Long sto_num);
	//리뷰 table의 정보를 가져오는 메소드
	
	public void revInsert(ReviewVO rev_vo);
	//리뷰 table에 리뷰 데이터를 추가하는 메소드
	
	public long getAvg(Long sto_num);
	//입력한 업체 번호에 해당하는 별점 데이터의 평균을 리턴하는 메소드
}
