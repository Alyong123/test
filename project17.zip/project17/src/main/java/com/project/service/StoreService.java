package com.project.service;

import com.project.domain.StoreVO;

public interface StoreService {  //작성자 : 신승배, 공영빈
	public void store_register(StoreVO store) throws Exception; //작성자 : 신승배
	// 업체를  추가하는 interface 메소드
	public StoreVO getList1(Long sto_num); // 작성자 : 공영빈
	// 업체 정보를 가져오는 interface 메소드
}// 
