package com.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.domain.Criteria;
import com.project.domain.JeboBoardVO;
import com.project.mapper.JeboBoardMapper;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class JeboBoardServiceImpl implements JeboBoardService{
	
	@Setter(onMethod_ = @Autowired)
	private JeboBoardMapper mapper;

	@Override
	public void register(JeboBoardVO jebo_board) {
		log.info("register...."+jebo_board);
		mapper.insertSelectKey(jebo_board);
	}

	@Override
	public JeboBoardVO get(Long jebo_num) {
		log.info("get....."+jebo_num);
		return mapper.read(jebo_num);
	}

	@Override
	public boolean modify(JeboBoardVO jebo_board) {
		log.info("Modify....."+jebo_board);
		return mapper.update(jebo_board) == 1;
	}

	@Override
	public boolean remove(Long jebo_num) {
		log.info("remove..." + jebo_num);
		return mapper.delete(jebo_num) ==1	;
	}

	@Override
	public List<JeboBoardVO> getList() {
		log.info("get List.............");
		return mapper.getList();
	}

	@Override
	public int getTotal(Criteria cri) {
		log.info("get total count");
		return mapper.getTotalCount(cri);
	}

	@Override
	public List<JeboBoardVO> getList(Criteria cri) {
		log.info("get List with criteria..." + cri);
		return mapper.getListWithPaging(cri);
	}
	
	@Override
	public List<JeboBoardVO> getIdList(String jebo_writer) {
		return mapper.readId(jebo_writer);		
	}

}//end class