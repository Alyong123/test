package com.project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.domain.ReviewVO;
import com.project.mapper.ReviewMapper;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor
public class ReviewServiceImpl implements ReviewService{
	
	@Setter(onMethod_ = @Autowired)
	private ReviewMapper mapper;

	@Override
	public List<ReviewVO> getList1(Long sto_num) {
		// TODO Auto-generated method stub
		return mapper.getList1(sto_num);
	}

	@Override
	public void revInsert(ReviewVO rev_vo) {
		// TODO Auto-generated method stub
		mapper.revInsert(rev_vo);
	}

	@Override
	public long getAvg(Long sto_num) {
		// TODO Auto-generated method stub
		return mapper.getAvg(sto_num);
	}

}//ReviewService.java를 오버라이딩함.
