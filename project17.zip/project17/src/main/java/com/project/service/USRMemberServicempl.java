package com.project.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.domain.USRMemberVO;
import com.project.mapper.USRMemberMapper;

import lombok.AllArgsConstructor;
import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
@AllArgsConstructor

//작성자 : 신승배
public class USRMemberServicempl implements USRMemberService {
	
	@Setter(onMethod_ = @Autowired)  //의존성 주입
	private USRMemberMapper mapper; // USRMemberMapper의 메소드를 사용하기 위해  mapper라는 객체생성

	@Override
	public void register(USRMemberVO usr) throws Exception {
		log.info("register...."+usr);
		mapper.usr_insert(usr);
		// 유저 정보를   db에 추가하는 메소드를 오버라이딩함
	}


	@Override
	public USRMemberVO user_login(String usr_id, String usr_passwd) {
		log.info("register...."+usr_id+usr_passwd);
		return mapper.login(usr_id, usr_passwd);
		// 아이디와 비밀번호가 일치하는 유저를 db에서 찾아주는 메소드를 오버라이딩함
	}


	@Override
	public void  usr_modify(USRMemberVO usr) {
		log.info("register...."+usr);
		 mapper.update(usr);
		// 유저 정보 를  db에서수정하는   메소드를 오버라이딩함
	}


}
//작성자 : 신승배