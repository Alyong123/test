package com.project.mapper;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.project.domain.USRMemberVO;
@Mapper
public interface USRMemberMapper { //작성자 : 신승배
	// 회원 가입
	public void usr_insert(USRMemberVO usr ) ;
	
	
	// 로그인
	public USRMemberVO login(@Param("usr_id") String usr_id, @Param("usr_passwd") String usr_passwd);
	
	//회원정보 수정
	public void update(USRMemberVO usr);
	
	
	
}//USRMemberMapper.xml의 메소드
