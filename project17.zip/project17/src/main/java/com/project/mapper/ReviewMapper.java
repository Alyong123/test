package com.project.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.project.domain.ReviewVO;

@Mapper
public interface ReviewMapper { //작성자 : 공영빈
	public List<ReviewVO> getList1(Long sto_num);
	
	public void revInsert(ReviewVO rev_vo);
	
	public long getAvg(Long sto_num);
} //ReviewMapper.xml의 메소드
