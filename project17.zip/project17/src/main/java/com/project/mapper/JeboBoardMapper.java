package com.project.mapper;

import java.util.List;

import com.project.domain.Criteria;
import com.project.domain.JeboBoardVO;

public interface JeboBoardMapper {
	
	public int getTotalCount(Criteria cri);
	
	public List<JeboBoardVO> getListWithPaging( Criteria cri);
	
	public List<JeboBoardVO> getList();

	public void insert(JeboBoardVO jebo_board);

	public void insertSelectKey(JeboBoardVO jebo_board);
	
	public JeboBoardVO read(Long jebo_num);
	
	public int delete (Long jebo_num);
	
	public int update(JeboBoardVO jebo_board);
	
	public List<JeboBoardVO> readId(String jebo_writer);

}// end inter