package com.project.mapper;

import java.util.List;

import com.project.domain.HomeVO;

public interface HomeMapper { //작성자 : 공영빈
	
	public List<HomeVO> getList1();
	
	public List<HomeVO> getList2();
	
	public List<HomeVO> getList3();
	
	public List<HomeVO> getList4();
	
} //HomeMapper.xml의 메소드
