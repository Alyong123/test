package com.project.mapper;

import java.util.List;

import com.project.domain.Criteria;
import com.project.domain.QnABoardVO;

public interface QnABoardMapper {
	
	public int getTotalCount(Criteria cri);
	
	public List<QnABoardVO> getListWithPaging( Criteria cri);
	
	public List<QnABoardVO> getList();

	public void insert(QnABoardVO qna_board);

	public void insertSelectKey(QnABoardVO qna_board);
	
	public QnABoardVO read(Long qna_num);
	
	public int delete (Long qna_num);
	
	public int update(QnABoardVO qna_board);
	
	public List<QnABoardVO> readId(String qna_writer);

}// end inter