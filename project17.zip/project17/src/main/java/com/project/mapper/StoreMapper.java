package com.project.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.project.domain.StoreVO;


@Mapper
public interface StoreMapper { //작성자 : 공영빈, 신승배
	// 가게 추가
	public void store_insert(StoreVO store );
	
	public StoreVO getList1(Long sto_num);
	
}//storeMapper.xml의 메소드
