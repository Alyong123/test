package com.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.project.domain.ReviewVO;
import com.project.domain.StoreVO;
import com.project.service.ReviewService;
import com.project.service.StoreService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;


@Log4j
@Controller
@RequestMapping("/store*")
public class StoreController {
	
	// 작성자: 신승배
	@Setter(onMethod_ = @Autowired) //의존성 주입
	private StoreService service; // StoreService의 메소드를 사용하기 위해  service라는 객체생성
	
	// 작성자: 공영빈
	@Setter(onMethod_ = @Autowired) //의존성 주입
	private ReviewService review_service; // ReviewService의 메소드를 사용하기 위해  service라는 객체생성
	

	// 작성자: 신승배
	@GetMapping("/sto_register") // 가게정보 추가 jsp로연결
	public void store_register() { 
		log.info("store_register....");		
	}//end uploadAj...
	
	
	
	// 작성자: 신승배
	@PostMapping("/sto_register")
	public String register(StoreVO  store, RedirectAttributes rttr) throws Exception {
		//가제정보 추가 버튼을 눌렀을때 가제정보 추가 에서  입력한 값들을 StoreVO 형태로 post 방식을 통해 받아와서 밑에 명령들을 실행합니다
		log.info( "sto_register: " +store);		
		service.store_register(store);		
		//  StoreVO 형태로 받아온 가게정보를  DB에 저장합니다
		rttr.addFlashAttribute("result", store.getSto_name());		
		// 리다이렉트를 통해 StoreVO 형태의 가게정보에서 name정보를  result라는 객체에 저장합니다.
		return "redirect:/store/sto_register";	
		// 모든 과정이 끝나면  해당주소로 이동합니다
	}
	
	@GetMapping({"/get"}) 
	public void get(@RequestParam("sto_num") Long sto_num, Model model) { //작성자 : 공영빈
		// 홈 화면에서 업체 마커를 클릭하면 그 마커의 업체 번호(sto_num)를 사용해 업체 페이지의 정보를 가져옵니다

		model.addAttribute("sto", service.getList1(sto_num)); 
		//업체 번호를 사용해 DB의 업체 table에 있는 업체 정보를 StoreVO형태로 가져오고, store/get.jsp에서 sto로 사용하기 위해  addAttribute로 넘겨줍니다.
		model.addAttribute("review", review_service.getList1(sto_num));
		//업체 번호를 사용해 DB의 리뷰 table에 있는 리뷰 정보를 ReviewVO형태로 가져오고, store/get.jsp에서 review로 사용하기 위해  addAttribute로 넘겨줍니다.
		model.addAttribute("avgStar", review_service.getAvg(sto_num));
		//업체 번호를 사용해 DB의 리뷰 table에 있는 리뷰 점수 평균을 store/get.jsp에서 avgSar로 사용하기 위해  addAttribute로 넘겨줍니다.

	}//end get, 처음 업체 정보를 보여줄 때 get 방식으로 진행됩니다.
	
	@RequestMapping(value = "/get", method = RequestMethod.POST)
	public void register(ReviewVO rev, Model model) throws JsonProcessingException { //작성자 : 공영빈
		// store.get 에서 리뷰를 작성하면 리뷰 테이블에 입력된 리뷰가 추가되기 위해 post 방식으로 다시 store/get으로 접근합니다.
		log.info( "test: " + rev);		
		review_service.revInsert(rev); //입력한 리뷰를 DB에 추가합니다.
		model.addAttribute("sto", service.getList1((long)rev.getSto_num()));
		//store/get.jsp에서 넘겨받은 ReviewVO에서 업체 정보를 가져올 때 필요한 sto_num을 getSto_num()으로 가져오고, 그 값으로 get방식과 같이 진행합니다.
		model.addAttribute("review", review_service.getList1((long)rev.getSto_num()));	
		//store/get.jsp에서 넘겨받은 ReviewVO에서 리뷰 정보를 가져올 때 필요한 sto_num을 getSto_num()으로 가져오고, 그 값으로 get방식과 같이 진행합니다.
		model.addAttribute("avgStar", review_service.getAvg((long)rev.getSto_num()));
		//store/get.jsp에서 넘겨받은 ReviewVO에서 리뷰 평균을 가져올 때 필요한 sto_num을 getSto_num()으로 가져오고, 그 값으로 get방식과 같이 진행합니다.
	} //end post, jsp파일에서 추가로 세팅해 줄 필요 없게 각 addAttribute로 넘겨줄 값의 이름을 get방식과 동일하게 설정합니다.
	
}
