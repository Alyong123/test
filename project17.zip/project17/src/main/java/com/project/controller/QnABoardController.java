package com.project.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.domain.Criteria;
import com.project.domain.PageDTD;
import com.project.domain.QnABoardVO;
import com.project.service.QnABoardService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("/qna_board/*")
@AllArgsConstructor
public class QnABoardController {

	private QnABoardService qna_service;

	@GetMapping("/register")
	public void register() {
	}// end reg

	@GetMapping("/list")
	public void list(Criteria cri, Model model) {
		log.info("readId" + cri);
		model.addAttribute("readId", qna_service.getList(cri));
		
		//PageDTD 구성하기 위해 전체데이터 수 필요해서 임의의값 123 지정
//		model.addAttribute("pageMaker", new PageDTD(cri, 123));
		
		int total = qna_service.getTotal(cri);
		model.addAttribute("pageMaker", new PageDTD(cri, total));
	}//end list

//	@GetMapping("/list")
//	public void list(Criteria cri, Model model) {
//		log.info("list" + cri);
//		model.addAttribute("list", qna_service.getList(cri));
//
//		 //PageDTD 구성하기 위해 전체데이터 수 필요해서 임의의값 123 지정
//		 model.addAttribute("pageMaker", new PageDTD(cri, 123));
//
//		int total = qna_service.getTotal(cri);
//		model.addAttribute("pageMaker", new PageDTD(cri, total));
//	}// end list

	@PostMapping("/list")
	public void user_login(@RequestParam("qna_writer") String qna_writer, RedirectAttributes rttr, Model model)
			throws Exception {

		log.info("listpost");
		log.info(qna_writer);

		if (qna_writer == null) {
			model.addAttribute("readId", qna_service.getList());
		} else {

			List<QnABoardVO> readId = qna_service.getIdList(qna_writer);
			log.info(readId);
			log.info("test2");
			model.addAttribute("readId", readId);
		}
	}

//	@GetMapping("/list")
//	public void list(Criteria cri,  Model model) {
//		log.info("list" + cri);
//		model.addAttribute("list", qna_service.getList(cri));
//		
//		//PageDTD 구성하기 위해 전체데이터 수 필요해서 임의의값 123 지정
//		//model.addAttribute("pageMaker", new PageDTD(cri, 123));
//		
//		int total = qna_service.getTotal(cri);
//		model.addAttribute("pageMaker", new PageDTD(cri, total));
//	}//end list

	@PostMapping("/register")
	public String register(QnABoardVO qna_board, RedirectAttributes rttr) {

		log.info("register: " + qna_board);
		qna_service.register(qna_board);
		rttr.addFlashAttribute("result", qna_board.getQna_num());
		return "redirect:/qna_board/list";
	}// end regster

	@GetMapping({ "/get", "/modify" })
	public void get(@RequestParam("qna_num") Long qna_num, Model model) {
		log.info("/get or Modify");
		model.addAttribute("qna_board", qna_service.get(qna_num));

	}// end get

	@PostMapping("/modify")
	public String modify(QnABoardVO qna_board, RedirectAttributes rttr
			, @ModelAttribute("cri") Criteria cri) {
		log.info("modify :" + qna_board);

		if (qna_service.modify(qna_board)) {
			rttr.addFlashAttribute("result", "succes");
		} // end if
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		return "redirect:/qna_board/list";
	}// end modify

//	@PostMapping("/modify")
//	public String modify(QnABoardVO qna_board, RedirectAttributes rttr) {
//		log.info("modify :" + qna_board);
//		if (qna_service.modify(qna_board)) {
//			rttr.addFlashAttribute("result", "succes");
//		}
//		return "redirect:/qna_board/list";
//	}

	@PostMapping("/remove")
	public String remove(@RequestParam("qna_num") Long qna_num, @ModelAttribute("cri") Criteria cri, RedirectAttributes rttr) {
		log.info("remove..." + qna_num);
		if (qna_service.remove(qna_num)) {
			rttr.addFlashAttribute("result", "success");
		} // end if
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		return "redirect:/qna_board/list";
	}// end remove

//	@PostMapping("/remove")
//	public String remove(@RequestParam("qna_num") Long qna_num, RedirectAttributes rttr) {
//
//		log.info("remove..." + qna_num);
//		if (qna_service.remove(qna_num)) {
//			rttr.addFlashAttribute("result", "success");
//		} // end if
//		return "redirect:/qna_board/list";
//	}// end remove

}// end class