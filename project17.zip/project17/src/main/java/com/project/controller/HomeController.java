package com.project.controller;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.project.service.HomeService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

/**
 * Handles requests for the application home page.
 */
@Log4j
@Controller
@RequestMapping("/*")
@AllArgsConstructor
public class HomeController {

	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);

	private HomeService home_service;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) throws JsonProcessingException {
		logger.info("Welcome home! The client locale is {}.", locale);
		log.info("category");
		
		ObjectMapper mapper1 = new ObjectMapper(); //데이터를 json의 모양으로 바꿔주는 역할을 할 ObjectMapper 객체
		String jsonCate1 = mapper1.writeValueAsString(home_service.getList1());
		//DB에서 가져온 카테고리 값이 1인 데이터를 json의 모양으로 바꿔서 String으로 저장
		model.addAttribute("cate1", jsonCate1); //home.jsp에서 cate1으로 사용하기 위해 addAttribute로 넘겨줌
		
		ObjectMapper mapper2 = new ObjectMapper(); //데이터를 json의 모양으로 바꿔주는 역할을 할 ObjectMapper 객체
		String jsonCate2 = mapper2.writeValueAsString(home_service.getList2());
		//DB에서 가져온 카테고리 값이 2인 데이터를 json의 모양으로 바꿔서 String으로 저장
		model.addAttribute("cate2", jsonCate2);//home.jsp에서 cate2으로 사용하기 위해 addAttribute로 넘겨줌
		 
		ObjectMapper mapper3 = new ObjectMapper(); //데이터를 json의 모양으로 바꿔주는 역할을 할 ObjectMapper 객체
		String jsonCate3 = mapper3.writeValueAsString(home_service.getList3());
		//DB에서 가져온 카테고리 값이 3인 데이터를 json의 모양으로 바꿔서 String으로 저장
		model.addAttribute("cate3", jsonCate3);//home.jsp에서 cate3으로 사용하기 위해 addAttribute로 넘겨줌
		
		ObjectMapper mapper4 = new ObjectMapper(); //데이터를 json의 모양으로 바꿔주는 역할을 할 ObjectMapper 객체
		String jsonCate4 = mapper4.writeValueAsString(home_service.getList4());
		//DB에서 가져온 카테고리 값이 4인 데이터를 json의 모양으로 바꿔서 String으로 저장
		model.addAttribute("cate4", jsonCate4);//home.jsp에서 cate4으로 사용하기 위해 addAttribute로 넘겨줌

		return "home";

	} // 메인 화면이 실행될 때 get방식으로 표현.
} //작성자 : 공영빈