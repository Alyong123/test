// 작성자 : 신승배
package com.project.controller;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.domain.USRMemberVO;
import com.project.service.USRMemberService;

import lombok.Setter;
import lombok.extern.log4j.Log4j;
@Log4j //  로그를 기록하는 Logger 변수를 생성한다.
@Controller //  해당 어노테이션이 적용된 클래스는 "Controller"임을 나타나고, bean으로 등록되며 해당 클래스가 Controller로 사용됨을 Spring Framework에 알립니다.
@RequestMapping("/user*") // views의 user폴더 안에 jsp들을  연결하기위한 경로를 연결해줌
public class USRMemberController {
	
	@Setter(onMethod_ = @Autowired)  //의존성 주입
	private USRMemberService service; // USRMemberService의 메소드를 사용하기 위해  service라는 객체생성


	@GetMapping("/login") // 로그인 jsp로 연결
	public void login() {
		log.info("login....");		
	}//end uploadAj...
	
	@GetMapping("/register") // 회원가입 jsp로 연결
	public void register() {
		log.info("register....");		
	}//end uploadAj...
	
	
	
	@GetMapping("/modify") //회원정보 수정 jsp로 연결
	public void modify() {
		log.info("modify....");		
	}//end uploadAj...
	
	@PostMapping("/register") 
	public String register(USRMemberVO  usr, RedirectAttributes rttr) throws Exception {
		//회원가입 버튼을 눌렀을때 회원가입 창에서  입력한 값들을 USRMemberVO 형태로 post 방식을 통해 받아와서 밑에 명령들을 실행합니다
		log.info( "register: " +usr); 
		service.register(usr);
		//  USRMemberVO 형태로 받아온 회원가입 정보를  DB에 저장합니다
		rttr.addFlashAttribute("result", usr.getUsr_id());	
		// 리다이렉트를 통해 USRMemberVO 형태의 회원정보에서 ID정보를  result라는 객체에 저장합니다.
		return "redirect:/user/login";	
		// 모든 과정이 끝나면  해당주소로 이동합니다
	}
	
	
	@RequestMapping(value = "/login", method = RequestMethod.POST) 
	public String user_login(USRMemberVO  usr, HttpServletRequest req,RedirectAttributes rttr) throws Exception {
		//로그인 버튼을 눌렀을때 로그인 창에서  입력한 값들을 USRMemberVO 형태로 post 방식을 통해 받아와서 밑에 명령들을 실행합니다
		log.info( "user: " +usr);	
		
		HttpSession session = req.getSession();
		//로그인한 유저정보를 담을 세션 객체 생성
		USRMemberVO login = service.user_login(usr.getUsr_id(), usr.getUsr_passwd());
		// USRMemberVO 형태로 받아온 로그인 정보에서  ID와 비밀번호가 일치하는 유저를 DB에서 찾아와 login이라는 객체에 저장합니다
		if(login == null) {
		// login 객체가  null이라면 즉 ID와 비밀번호가 일치하는 유저가 없다면
			session.setAttribute("usr_login", null); 
			//usr_login이라는 세션 만드는데 null값을 저장합니다
			rttr.addFlashAttribute("msg", false);
			//리다이렉트를 통해 msg라는 객체에 false값을 저장합니다---이를 통해 로그인창에서 아이디와 비밀번호가 맞았는지 경고창을 띄우고자 합니다
		}
		
		// Usr_adtest는 식별번호 1이면 일반유저 2면 관리자계정
		else if(login.getUsr_adtest()==1) {
			// login 객체에 값이 있을때  Usr_adtest가 1이라면 
			session.setAttribute("usr_login", login);
			//usr_login이라는 세션 만들고  login 객체값을 저장합니다
		}
		else if(login.getUsr_adtest()==2) {
			// login 객체에 값이 있을때  Usr_adtest가 1이 아니고 2라면
			session.setAttribute("admin_login", login);
			//admin_login이라는 세션 만들고  login 객체값을 저장합니다
	}

		
		log.info( "user_login: " +login);	
		log.info( "admin_login: " +login);
	
		return "redirect:/user/login";
		// 모든 과정이 끝나면  해당주소로 이동합니다
	}
	
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) throws Exception{
	// 로그아웃 버튼을 눌렀을때  명령을 실행합니다
		
		session.invalidate();
		// 세션을 초기화함으로써 저장되있던 로그인정보를 초기화합니다
		
		return "redirect:/user/login";
		// 모든 과정이 끝나면  해당주소로 이동합니다
	}
	
	
	@PostMapping("/modify")
	public String modify(USRMemberVO  usr, HttpSession session,RedirectAttributes rttr) throws Exception {
		//회원가입 수정 버튼을 눌렀을때 회원가입수정 창에서  입력한 값들을 USRMemberVO 형태로 post 방식을 통해 받아와서 밑에 명령들을 실행합니다
		log.info( "modify: " +usr);		
		service.usr_modify(usr);
		//  USRMemberVO 형태로 받아온 회원가입수정 정보를  DB에 업데이트합니다
		rttr.addFlashAttribute("result", usr.getUsr_id());	
		// 리다이렉트를 통해 USRMemberVO 형태의 회원정보에서 ID정보를  result라는 객체에 저장합니다.
		session.invalidate();
		// 세션을 초기화함으로써 저장되있던 로그인정보를 초기화합니다
		return "redirect:/user/login";	
		// 모든 과정이 끝나면  해당주소로 이동합니다
	}
		
		
		
	

} //작성자:  신승배



