package com.project.controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.project.domain.Criteria;
import com.project.domain.JeboBoardVO;
import com.project.domain.PageDTD;
import com.project.service.JeboBoardService;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@Controller
@RequestMapping("/jebo_board/*")
@AllArgsConstructor
public class JeboBoardController {

	private JeboBoardService jebo_service;
	
	@GetMapping("/register")
	public void register() {
	}//end reg


//	@GetMapping("/list")
//	public void list(Model model) {
//		log.info("list");
//		log.info(jebo_service.getList());
//		model.addAttribute("readId", jebo_service.getList());
//	}// end list
	
	@GetMapping("/list")
	public void list(Criteria cri, Model model) {
		log.info("readId" + cri);
		model.addAttribute("readId", jebo_service.getList(cri));
		
		//PageDTD 구성하기 위해 전체데이터 수 필요해서 임의의값 123 지정
//		model.addAttribute("pageMaker", new PageDTD(cri, 123));
		
		int total = jebo_service.getTotal(cri);
		model.addAttribute("pageMaker", new PageDTD(cri, total));
	}//end list
	
	@PostMapping("/list")
	public void user_login(@RequestParam("jebo_writer") String jebo_writer , RedirectAttributes rttr, Model model) throws Exception {

		log.info("listpost");
		log.info(jebo_writer);
		
		if(jebo_writer == null) {
			model.addAttribute("readId", jebo_service.getList());
		} else {
		
		List<JeboBoardVO> readId = jebo_service.getIdList(jebo_writer);
			log.info(readId);
			log.info("test2");
			model.addAttribute("readId", readId);
		}
	}
//	@GetMapping("/list")
//	public void list(Criteria cri,  Model model) {
//		log.info("list" + cri);
//		model.addAttribute("list", jebo_service.getList(cri));
//		
//		//PageDTD 구성하기 위해 전체데이터 수 필요해서 임의의값 123 지정
//		//model.addAttribute("pageMaker", new PageDTD(cri, 123));
//		
//		int total = jebo_service.getTotal(cri);
//		model.addAttribute("pageMaker", new PageDTD(cri, total));
//	}//end list
	
	@PostMapping("/register")
	public String register(JeboBoardVO jebo_board, RedirectAttributes rttr) {
		
		log.info("register: " + jebo_board);
		jebo_service.register(jebo_board);
		rttr.addFlashAttribute("result", jebo_board.getJebo_num());
		return "redirect:/jebo_board/list";
	}// end regster

	@GetMapping({"/get","/modify"})
	public void get(@RequestParam("jebo_num") Long jebo_num, Model model) {
		log.info("/get or Modify");
		model.addAttribute("jebo_board", jebo_service.get(jebo_num));	
	}//end get
	
//	@PostMapping("/modify")
//	public String modify(JeboBoardVO jebo_board, RedirectAttributes rttr) {
//		log.info("modify :" + jebo_board);
//		if (jebo_service.modify(jebo_board)) {
//			rttr.addFlashAttribute("result", "succes");
//		}
//		return "redirect:/jebo_board/list";
//	}
	
	@PostMapping("/modify")
	public String modify(JeboBoardVO jebo_board, RedirectAttributes rttr
			, @ModelAttribute("cri") Criteria cri) {
		log.info("modify :" + jebo_board);

		if (jebo_service.modify(jebo_board)) {
			rttr.addFlashAttribute("result", "succes");
		} // end if
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		return "redirect:/jebo_board/list";
	}// end modify

//	@PostMapping("/remove")
//	public String remove(@RequestParam("jebo_num") Long jebo_num, RedirectAttributes rttr) {
//
//		log.info("remove..." + jebo_num);
//		if (jebo_service.remove(jebo_num)) {
//			rttr.addFlashAttribute("result", "success");
//		} // end if
//		return "redirect:/jebo_board/list";
//	}// end remove
	
	@PostMapping("/remove")
	public String remove(@RequestParam("jebo_num") Long jebo_num, @ModelAttribute("cri") Criteria cri, RedirectAttributes rttr) {
		log.info("remove..." + jebo_num);
		if (jebo_service.remove(jebo_num)) {
			rttr.addFlashAttribute("result", "success");
		} // end if
		rttr.addAttribute("pageNum", cri.getPageNum());
		rttr.addAttribute("amount", cri.getAmount());
		return "redirect:/jebo_board/list";
	}// end remove

}// end class